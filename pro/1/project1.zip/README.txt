Website URL:
http://d296afw9zoe5wk.cloudfront.net/index.html

S3 Bucket Name:
mikeajala001